import os
import shutil
import logging

logging.basicConfig(
    filename='DirectoryOrganizer.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

class DirectoryOrganizer:
    EXTENSION_MAP = {
        '.txt': 'Documents', '.csv': 'Documents', '.md': 'Documents',
        '.jpg': 'Images', '.png': 'Images',
        '.mp4': 'Videos', '.avi': 'Videos',
        '.mp3':'Music','.flac':'Music'
    }
    
    def __init__(self, target_dir):
        self.target_dir = os.path.abspath(target_dir) 
        
    def __repr__(self):
        return f"DirectoryOrganizer(target_dir='{self.target_dir}')"     
    @staticmethod
    def get_extension(filename):
        _, ext = os.path.splitext(filename)
        return ext.lower()  

    def organize(self):
        if not os.path.exists(self.target_dir):
            logging.error(f"目标路径不存在: {self.target_dir}")
            return False

        files = os.listdir(self.target_dir)
        
        for item in files:
            source_path = os.path.join(self.target_dir, item)

            if not os.path.isfile(source_path):
                continue
                
            ext = self.get_extension(item)
            target_folder_name = self.EXTENSION_MAP.get(ext, 'Others') 
            
            target_folder_path = os.path.join(self.target_dir, target_folder_name)
            os.makedirs(target_folder_path, exist_ok=True)
            
            dest_path = os.path.join(target_folder_path, item)
            try:
                shutil.move(source_path, dest_path)
                
                if target_folder_name == 'Others':
                    logging.warning(f"未知文件类型归类: [{item}] -> Others")
                else:
                    logging.info(f"成功移动: [{item}] -> {target_folder_name}")
                    
            except Exception as e:
                logging.error(f"移动失败: [{item}], 错误详情: {e}")
                
        return True
class DeepDirectoryOrganizer(DirectoryOrganizer):
    def __init__(self,target_dir):
        super().__init__(target_dir)
    def organize(self):
        if not os.path.exists(self.target_dir):
            logging.error(f"目标路径不存在: {self.target_dir}")
            return False
        not_folders={'Documents', 'Images', 'Videos', 'Others','Music'}
        for root,dirs,files in os.walk(self.target_dir,topdown=True):
                dirs[:] = [d for d in dirs if d not in not_folders]
                for file in files:
                    source_path=os.path.join(root,file)
                    if not os.path.isfile(source_path):
                        continue
                    ext = DirectoryOrganizer.get_extension(file)
                    target_folder_name = self.EXTENSION_MAP.get(ext, 'Others') 
                        
                    target_folder_path = os.path.join(self.target_dir, target_folder_name)
                    os.makedirs(target_folder_path, exist_ok=True)
                        
                    dest_path = os.path.join(target_folder_path, file)
                    try:
                        shutil.move(source_path, dest_path)
                            
                        if target_folder_name == 'Others':
                            logging.warning(f"未知文件类型归类: [{file}] -> Others")
                        else:
                            logging.info(f"成功移动: [{file}] -> {target_folder_name}")
                                
                    except Exception as e:
                        logging.error(f"移动失败: [{file}], 错误详情: {e}")
                        
        return True


if __name__ == "__main__":
    print("="*40)
    print("智能文件收纳整理系统")
    print("="*40)
    
    while True:
        work_path = input("请输入需要整理的文件夹路径 (输入 exit 退出):\n>> ").strip()
        
        if work_path.lower() == 'exit':
            print("系统退出。")
            break
            
        organizer = DeepDirectoryOrganizer(work_path)
        
        logging.info(f"--- 开始全新整理任务: {repr(organizer)} ---")
        
        print(f" 正在整理 {work_path} ...")
        
        success = organizer.organize()
        
        if success:
            print(" 整理完成！请查看文件夹或日志文件。")
        else:
            print(" 整理失败，请检查路径是否正确。")