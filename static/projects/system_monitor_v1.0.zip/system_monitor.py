import smtplib,os,psutil
from email.message import EmailMessage

email_address=os.environ.get('QQ_email_User')
email_code=os.environ.get('QQ_email_Code')
email_contacts=os.environ.get('QQ_email_contacts')
Fromer=email_address
Contacts=QQ_email_contacts
class System_Monitor:
    def __init__(self,cpu_percent):
        self.cpu_percent=cpu_percent
    def push_email(self):
        if (cpu_percent>1):
            message=EmailMessage()
            message['Subject']='ERROR!!!'
            message['From']=Fromer
            message['To']=Contacts
            message.set_content('Your computer`s cpu percent more than 80%!It maybe have a bad impact to your work.Please check your computer now!')
            with smtplib.SMTP('smtp.qq.com',587) as smtp:
                smtp.ehlo()
                smtp.starttls()
                smtp.ehlo()
                smtp.login(email_address,email_code)
                smtp.send_message(message)
            print(f"The email is already push to {Contacts}")
    @staticmethod
    def catchdata():
        cpu_percent=psutil.cpu_percent(interval=1)
        return cpu_percent

if __name__=="__main__":
    cpu_percent=System_Monitor.catchdata()
    print(f"Your cpu percent is {cpu_percent}% now")
    monitor = System_Monitor(cpu_percent)
    monitor.push_email()

