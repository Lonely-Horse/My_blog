You should setting your address on your enviroment,but I think you should search about the knowledge,
I just tell you about how to setting the enviroment about linux or mac.Such as:
export QQ_email_User="xxxxx"
export QQ_email_Code="xxxxx"
export QQ_email_contacts="xxxxx"
You should setting the "xxxxx" and copy the code in '.bash_profile'
If you used the linux or mac,please use "nano ~/.bash_profile"
If you have some knowledge about python,you can setting your name in enviroment.
QQ_email_User must open your smtplib code and get your code.
OK,thank your reading. 

