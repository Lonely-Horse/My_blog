# 关于ansible的lac建设仓库

## 事先说明
    由于隐私问题，我并没有将inventory和host_vars文件夹推送到仓库，如若想要使用的或者说是想要学习的请查看https://https://github.com/Lonely-Horse/test_ansible