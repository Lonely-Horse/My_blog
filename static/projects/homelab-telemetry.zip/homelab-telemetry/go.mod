module homelab-telemetry

go 1.24.4
