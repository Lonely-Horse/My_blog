from pathlib import Path
import shutil
import logging

SCRIPT_DIR = Path(__file__).parent.resolve()
LOG_FILE_PATH = SCRIPT_DIR / 'DirectoryOrganizer.log'

logging.basicConfig(
    filename=LOG_FILE_PATH,
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

class DirectoryOrganizer:
    EXTENSION_MAP = {
        '.txt': 'Documents', '.csv': 'Documents', '.md': 'Documents',
        '.jpg': 'Images', '.png': 'Images',
        '.mp4': 'Videos', '.avi': 'Videos',
        '.mp3':'Music','.flac':'Music'
    }
    
    def __init__(self, target_dir):
        self.target_dir = Path(target_dir).resolve() 
        
    def __repr__(self):
        return f"DirectoryOrganizer(target_dir='{self.target_dir}')"     
    @staticmethod
    def get_extension(filename):
        ext = filename.suffix
        return ext.lower()  

    def organize(self):
        if not self.target_dir.is_dir():
            logging.error(f"目标路径不存在: {self.target_dir}")
            return False
        
        for item in self.target_dir.iterdir():
            if item.is_file():
                source_path = item
                if not source_path.is_file():
                    continue
                    
                ext = self.get_extension(item)
                target_folder_name = self.EXTENSION_MAP.get(ext, 'Others') 
                
                target_folder_path = self.target_dir / target_folder_name
                target_folder_path.mkdir(exist_ok=True)
                
                dest_path = target_folder_path / item.name
                try:
                    shutil.move(source_path, dest_path)
                    
                    if target_folder_name == 'Others':
                        logging.warning(f"未知文件类型归类: [{item}] -> Others")
                    else:
                        logging.info(f"成功移动: [{item}] -> {target_folder_name}")
                        
                except Exception as e:
                    logging.error(f"移动失败: [{item}], 错误详情: {e}")
                    
        return True
class DeepDirectoryOrganizer(DirectoryOrganizer):
    def __init__(self,target_dir):
        super().__init__(target_dir)
    def clean_empty_folders(self):
        for root, dirs, files in self.target_dir.walk(top_down=False):
            for dir_name in dirs:
                dir_path =root / dir_name
                if dir_path.is_dir():
                    try:
                        dir_path.rmdir()
                        logging.info(f"垃圾回收 - 已删除空文件夹: {dir_path}")
                    except Exception as e:
                        pass
    def organize(self):
        if not self.target_dir.exists():
            logging.error(f"目标路径不存在: {self.target_dir}")
            return False
        not_folders = set(self.EXTENSION_MAP.values())
        not_folders.add('Others')
        for root, dirs, files in self.target_dir.walk(top_down=True):
                dirs[:] = [d for d in dirs if d not in not_folders]
                for file in files:
                    source_path=root / file
                    if not source_path.is_file():
                        continue
                    ext = DirectoryOrganizer.get_extension(source_path)
                    target_folder_name = self.EXTENSION_MAP.get(ext, 'Others') 
                        
                    target_folder_path =self.target_dir / target_folder_name
                    target_folder_path.mkdir(exist_ok=True)
                        
                    dest_path = target_folder_path / file
                    try:
                        shutil.move(source_path, dest_path)
                            
                        if target_folder_name == 'Others':
                            logging.warning(f"未知文件类型归类: [{file}] -> Others")
                        else:
                            logging.info(f"成功移动: [{file}] -> {target_folder_name}")
                                
                    except Exception as e:
                        logging.error(f"移动失败: [{file}], 错误详情: {e}")
        self.clean_empty_folders()                
        return True


if __name__ == "__main__":
    print("="*40)
    print("智能文件收纳整理系统")
    print("="*40)
    
    while True:
        work_path = input("请输入需要整理的文件夹路径 (输入 exit 退出):\n>> ").strip()
        
        if work_path.lower() == 'exit':
            print("系统退出。")
            break
            
        organizer = DeepDirectoryOrganizer(work_path)
        
        logging.info(f"--- 开始全新整理任务: {repr(organizer)} ---")
        
        print(f" 正在整理 {work_path} ...")
        
        success = organizer.organize()
        
        if success:
            print(" 整理完成！请查看文件夹或日志文件。")
        else:
            print(" 整理失败，请检查路径是否正确。")