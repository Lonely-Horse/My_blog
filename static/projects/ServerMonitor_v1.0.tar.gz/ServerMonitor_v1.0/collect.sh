#!/bin/bash

# 1. 确保进入项目根目录 (无论 Crontab 在哪执行，先回家)
cd "$(dirname "$0")"

# 2. 设置 PYTHONPATH (这是最关键的一步！)
# 告诉 Python：当前目录(根目录)也是库文件的一部分
# 这样 app/collect_task.py 就能引用到 config 和 app 了
export PYTHONPATH=$PYTHONPATH:$(pwd)

# 3. 执行 Python 脚本
# 这样就可以直接指定文件路径了，不用 -m
python3 app/collect_task.py
