//删除函数 
void deleted()
{
	int select,i,flag,xian;
	int search_id;
	system("clear");//系统函数,cls是clears 清屏 
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t------------欢迎使用简历删除功能-------------\n");
	printf("\t\t\t-------------------------------------------------\n");
	printf("\n\n\n");
	
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t----------        1 按编号定位        -----------\n");
	printf("\t\t\t----------        2 退出删除          -----------\n");
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t请输入你的选择(1-2):");
	scanf("%d",&select);
				
	while(select<1 || select>2)
	{
		printf("\t\t\t你输入错误，请重新输入你的选择(1-2):");
		scanf("%d",&select);		
	}
	
	switch(select)
	{
		case 1:	printf("\n\n\n\t\t\t输入你所要删除的编号:");
				scanf("%d",&search_id);
				flag=0;//0表示假，一开始假设没有找到 
				for(i=0;i<=199;i++)
				{
					if(search_id==person[i].id)
					{
						system("clear");
                        for(xian=1;xian<=261;xian++)
                            printf("-");
                        printf("\n");
                        printf("|");
                        printf("%-10s","编号");	
                        printf("|");
                        printf("%-14s","姓名");
                        printf("|");	
                        printf("%-8s","性别");
                        printf("|");
                        printf("%-19s","出生年月日");
                        printf("|");	
                        printf("%-19s","联系电话");	
                        printf("|");
                        printf("%-28s","个人电子邮箱");
                        printf("|");
                        printf("%-14s","最高学历");
                        printf("|");
                        printf("%-24s","毕业院校");
                        printf("|");
                        printf("%-18s","专业");
                        printf("|");
                        printf("%-14s","工作年限");
                        printf("|");
                        printf("%-20s","求职意向");
                        printf("|");
                        printf("%-24s","技能特长");
                        printf("|");
                        printf("%-25s","前公司名称");
                        printf("|");
                        printf("%-25s","前公司任职时间");
                        printf("|");
                        printf("%-27s","前公司岗位职责");
                        printf("|");
                        printf("%-18s","备注");
                        printf("|");
                        printf("\n");
                        for(xian=1;xian<=261;xian++)
                            printf("-");
                        printf("\n");
                        if(person[i].id!=0) 
                        {
                            printf("|");
                            printf("%-8d",person[i].id);	
                            printf("|");
                            printf("%-12s",person[i].name);
                            printf("|");	
                            printf("%-6s",person[i].sex);
                            printf("|");
                            printf("%-14s",person[i].born);
                            printf("|");	
                            printf("%-15s",person[i].number);	
                            printf("|");
                            printf("%-22s",person[i].email);
                            printf("|");
                            printf("%-10s",person[i].max_study);
                            printf("|");
                            printf("%-20s",person[i].school);
                            printf("|");
                            printf("%-16s",person[i].major);
                            printf("|");
                            printf("%-10s",person[i].work_year);
                            printf("|");
                            printf("%-16s",person[i].think);
                            printf("|");
                            printf("%-20s",person[i].advantage);
                            printf("|");
                            printf("%-20s",person[i].company_name);
                            printf("|");
                            printf("%-18s",person[i].company_time);
                            printf("|");
                            printf("%-20s",person[i].company_work);
                            printf("|");
                            printf("%-16s",person[i].tip);
                            printf("|");
                            printf("\n");

                            for(xian=1;xian<=261;xian++)
                                printf("-");
                            printf("\n");
                        }					
							
							{
								system("clear");//系统函数,cls是clears 清屏 
									int select2;
				
									printf("\t\t\t-------------------------------------------------\n");
									printf("\t\t\t----------1 确定删除        2 放弃删除-----------\n");
									printf("\t\t\t-------------------------------------------------\n");
									printf("\t\t\t请输入你的选择(1 or 2):");
									scanf("%d",&select2);
												
									while(select2<1 || select2>2)
									{
										printf("\t\t\t你输入错误，请重新输入你的选择(1 or 2):");
										scanf("%d",&select2);		
									}
									
									if(select2==1)//删除 
									{
										person[i]=shanchu;
										printf("\n\n\n\t\t\t你确定删除，该药材的数据不存在！\n");
										save(); 
									}
									if(select2==2)//不删除 
									{
										printf("\n\n\n\t\t\t你放弃了删除，该药材的数据依然存在！\n"); 
									}								 
							}
						flag=1;//说明找到了 
                    	break; 
							
					}
				}
				
				if(flag==0)
					printf("\n\n\n\t\t\t不存在此药材！\n");
				
				deleted();//继续删除 
				break;

		case 2:break;	
	}
    printf("按回车继续...\n");
	getchar();
	getchar(); 			
}