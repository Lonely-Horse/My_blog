void menu()
{
	int select;
	system("clear");//系统函数,cls是clears 清屏 
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t--------------欢迎使用简历管理系统---------------\n");
	printf("\t\t\t------------     1 录入功能         -------------\n");
	printf("\t\t\t------------     2 输出功能         -------------\n");
	printf("\t\t\t------------     3 查询功能         -------------\n");
	printf("\t\t\t------------     4 修改功能         -------------\n");
	printf("\t\t\t------------     5 删除功能         -------------\n");
	printf("\t\t\t------------     6 统计功能         -------------\n");
	printf("\t\t\t------------     7 保存功能         -------------\n");
	printf("\t\t\t------------     8 读取功能         -------------\n");
	printf("\t\t\t------------     9 退出程序         -------------\n");
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t请输入你的选择(1-9):");
	scanf("%d",&select);

	while(select<1 || select>9)
	{
		printf("\t\t\t你输入错误，请重新输入你的选择(1-9):");
		scanf("%d",&select);		
	}
	
	switch(select)
	{
		case 1:input();menu();break;
		case 2:output();menu();break;
		case 3:search();menu();break;
		case 4:change();menu();break;
		case 5:deleted();menu();break;
		case 6:statistics();menu();break;
		case 7:save();menu();break;
		case 8:load();menu();break;
		case 9:exit(0);break;	
        
	}
} 