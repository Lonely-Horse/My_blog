void statistics()
{
	int select,i,j,total;
	char *p[4]={"博士","硕士","本科学士","专科学士"};
    int rs[4]={0};
    char *q[7]={"后端工程师","前端工程师","运维工程师","SRE工程师","网络安全工程师","测试工程师","产品经理"};
    int tj[7]={0};
	system("clear");//系统函数,cls是clears 清屏 
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t------------欢迎使用简历统计功能-----------------\n");
	printf("\t\t\t-------------------------------------------------\n");
	printf("\n\n\n");
	
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t----------        1 统计总简历数      -----------\n");
    printf("\t\t\t----------        2 各学历层次简介数  -----------\n");
	printf("\t\t\t----------        3 各求职意向简介数  -----------\n");
	printf("\t\t\t----------        4 退出排序          -----------\n");
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t请输入你的选择(1-4):");
	scanf("%d",&select);
				
	//必须保证输入的给select值是1 或者 2
	while(select<1 || select>4)
	{
		printf("\t\t\t你输入错误，请重新输入你的选择(1-4):");
		scanf("%d",&select);		
	}
	
	switch(select)
	{
		case 1:	total=0;
				for(i=0;i<=199;i++)
				{
					if(person[i].id!=0)
						total++;
				}
				printf("\n\n\n\t\t\t 一共有简历%d份\n",total);
                getchar();
                getchar();
				statistics();
				break;
        case 2:	for(j=0;j<=3;j++)
				{
					for(i=0;i<=199;i++)
					{
						if(strcmp(person[i].max_study,p[j])==0)
							rs[j]++;
					}
				}
				
				for(j=0;j<=3;j++)
				{
					printf("<%s>学历一共有学生%d名\n",p[j],rs[j]);
				}
				getchar();
                getchar();
				statistics();	
                break;
        case 3:	for(j=0;j<=6;j++)
				{
					for(i=0;i<=199;i++)
					{
						if(strcmp(person[i].think,q[j])==0)
							tj[j]++;
					}
				}
				
				for(j=0;j<=6;j++)
				{
					printf("<%s>专业一共有学生%d名\n",q[j],tj[j]);
				}
                getchar();
				getchar();
				statistics();		
				break;
		case 4:	break;
	}
}