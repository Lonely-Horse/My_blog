void all_change(int i)
{
	struct person temp;
	int select,j,xian;
	 
	system("clear");//系统函数,cls是clears 清屏 
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t----------欢迎使用简历信息全部修改功能-----------\n");
	printf("\t\t\t-------------------------------------------------\n");
	printf("\n\n\n");
				printf("输入编号:");
		here:	scanf("%d",&temp.id);//输入药材的编号
				for(j=0;j<=1499;j++)
				{
					if(temp.id==person[j].id && j!=i)
					{
						//你输入的学号和之前的学号相等，要重新输入，还要重新比较
						printf("你所输入的编号相同，请你重新输入学号:");
						goto here;  
					}
				}
				
				//输入之后的回车键处理掉
				getchar();
                printf("输入姓名:");
                fgets(person[i].name,sizeof person[i].name,stdin);
				person[i].name[strcspn(person[i].name, "\n")] = '\0';
                printf("输入性别:");
                fgets(person[i].sex,sizeof person[i].sex,stdin);
                person[i].sex[strcspn(person[i].sex, "\n")] = '\0';
                printf("输入出生年月日(以xxxx.xx.xx作为模板):");
                fgets(person[i].born,sizeof person[i].born,stdin);
                person[i].born[strcspn(person[i].born, "\n")] = '\0';
                printf("输入联系电话:");
                fgets(person[i].number,sizeof person[i].number,stdin);
				person[i].number[strcspn(person[i].number, "\n")] = '\0';
                printf("输入个人电子邮箱:");
                fgets(person[i].email,sizeof person[i].email,stdin);
				person[i].email[strcspn(person[i].email, "\n")] = '\0';
                printf("输入最高学历:");
                fgets(person[i].max_study,sizeof person[i].max_study,stdin);
                person[i].max_study[strcspn(person[i].max_study,"\n")] = '\0';
                printf("输入毕业院校:");
                fgets(person[i].school,sizeof person[i].school,stdin);
                person[i].school[strcspn(person[i].school,"\n")] = '\0';
                printf("输入专业:");
                fgets(person[i].major,sizeof person[i].major,stdin);
                person[i].major[strcspn(person[i].major,"\n")] = '\0';
                printf("输入工作年限:");
                fgets(person[i].work_year,sizeof person[i].work_year,stdin);
                person[i].work_year[strcspn(person[i].work_year,"\n")] = '\0';
                printf("输入求职意向:");
                fgets(person[i].think,sizeof person[i].think,stdin);
                person[i].think[strcspn(person[i].think,"\n")] = '\0';
                printf("输入技能特长:");
                fgets(person[i].advantage,sizeof person[i].advantage,stdin);
                person[i].advantage[strcspn(person[i].advantage,"\n")] = '\0';
                printf("输入工作时期公司的名称:");
                fgets(person[i].company_name,sizeof person[i].company_name,stdin);
                person[i].company_name[strcspn(person[i].company_name,"\n")] = '\0';
                printf("输入工作时期公司的任职时间:");
                fgets(person[i].company_time,sizeof person[i].company_time,stdin);
                person[i].company_time[strcspn(person[i].company_time,"\n")] = '\0';
                printf("输入工作时期公司的岗位职责:");
            	fgets(person[i].company_work,sizeof person[i].company_work,stdin);
                person[i].company_work[strcspn(person[i].company_work,"\n")] = '\0';
                printf("输入备注:");
                fgets(person[i].tip,sizeof person[i].tip,stdin);
                person[i].tip[strcspn(person[i].tip,"\n")] = '\0';
				
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t----------1 确定修改        2 放弃修改-----------\n");
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t请输入你的选择(1 or 2):");
	scanf("%d",&select);
				
	//必须保证输入的给select值是1 或者 2
	while(select<1 || select>2)
	{
		printf("\t\t\t你输入错误，请重新输入你的选择(1 or 2):");
		scanf("%d",&select);		
	}
	
	if(select==1)//确定修改
	{
		person[i]=temp;
		printf("\n\n\n\t\t\t你选择修改，数据已经修改成功!\n");
        for(xian=1;xian<=261;xian++)
            printf("-");
        printf("\n");
        printf("|");
        printf("%-10s","编号");	
        printf("|");
        printf("%-14s","姓名");
        printf("|");	
        printf("%-8s","性别");
        printf("|");
        printf("%-19s","出生年月日");
        printf("|");	
        printf("%-19s","联系电话");	
        printf("|");
        printf("%-28s","个人电子邮箱");
        printf("|");
        printf("%-14s","最高学历");
        printf("|");
        printf("%-24s","毕业院校");
        printf("|");
        printf("%-18s","专业");
        printf("|");
        printf("%-14s","工作年限");
        printf("|");
        printf("%-20s","求职意向");
        printf("|");
        printf("%-24s","技能特长");
        printf("|");
        printf("%-25s","前公司名称");
        printf("|");
        printf("%-25s","前公司任职时间");
        printf("|");
        printf("%-27s","前公司岗位职责");
        printf("|");
        printf("%-18s","备注");
        printf("|");
        printf("\n");
        for(xian=1;xian<=261;xian++)
            printf("-");
        printf("\n");
        
        for(xian=1;xian<=51;xian++)
            printf("-");
        printf("\n");
        
        for(i=0;i<=1499;i++)
        {
            printf("|");
            printf("%-8d",person[i].id);	
            printf("|");
            printf("%-12s",person[i].name);
            printf("|");	
            printf("%-6s",person[i].sex);
            printf("|");
            printf("%-14s",person[i].born);
            printf("|");	
            printf("%-15s",person[i].number);	
            printf("|");
            printf("%-22s",person[i].email);
            printf("|");
            printf("%-10s",person[i].max_study);
            printf("|");
            printf("%-20s",person[i].school);
            printf("|");
            printf("%-16s",person[i].major);
            printf("|");
            printf("%-10s",person[i].work_year);
            printf("|");
            printf("%-16s",person[i].think);
            printf("|");
            printf("%-20s",person[i].advantage);
            printf("|");
            printf("%-20s",person[i].company_name);
            printf("|");
            printf("%-18s",person[i].company_time);
            printf("|");
            printf("%-20s",person[i].company_work);
            printf("|");
            printf("%-16s",person[i].tip);
            printf("|");
            printf("\n");
                        
            for(xian=1;xian<=261;xian++)
                printf("-");
            printf("\n");
        }
                                
		//上述输出第i个同学后！建议保存！
		save();		 
	}
	if(select==2)//不修改
	{
		printf("\n\n\n\t\t\t你选择了放弃修改，数据保持原样!\n");
	}	
	printf("按回车继续...\n");
	getchar();
	getchar();	
} 



