void change()
{
	int select,i,flag,xian;
	int search_id;
	
	system("clear");//系统函数,cls是clears 清屏 
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t------------欢迎使用药材信息修改功能-------------\n");
	printf("\t\t\t-------------------------------------------------\n");
	printf("\n\n\n");
	
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t----------        1 按编号查询        -----------\n");
	printf("\t\t\t----------        2 退出修改          -----------\n");
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t请输入你的选择(1-2):");
	scanf("%d",&select);
    getchar();
				
	//必须保证输入的给select值是1 或者 2
	while(select<1 || select>2)
	{
		printf("\t\t\t你输入错误，请重新输入你的选择(1-2):");
		scanf("%d",&select);
        getchar();		
	}
	
	switch(select)
	{
		case 1:	printf("\n\n\n\t\t\t输入你所要查询的编号:");
				scanf("%d",&search_id);
				flag=0;
				for(int k=0;k<=199;k++)
				{
					if(search_id==person[k].id)
					{
						int idx = k;
                        for(xian=1;xian<=261;xian++)
                            printf("-");
                        printf("\n");
                        printf("|");
                        printf("%-10s","编号");	
                        printf("|");
                        printf("%-14s","姓名");
                        printf("|");	
                        printf("%-8s","性别");
                        printf("|");
                        printf("%-19s","出生年月日");
                        printf("|");	
                        printf("%-19s","联系电话");	
                        printf("|");
                        printf("%-28s","个人电子邮箱");
                        printf("|");
                        printf("%-14s","最高学历");
                        printf("|");
                        printf("%-24s","毕业院校");
                        printf("|");
                        printf("%-18s","专业");
                        printf("|");
                        printf("%-14s","工作年限");
                        printf("|");
                        printf("%-20s","求职意向");
                        printf("|");
                        printf("%-24s","技能特长");
                        printf("|");
                        printf("%-25s","前公司名称");
                        printf("|");
                        printf("%-25s","前公司任职时间");
                        printf("|");
                        printf("%-27s","前公司岗位职责");
                        printf("|");
                        printf("%-18s","备注");
                        printf("|");
                        printf("\n");
                        for(xian=1;xian<=261;xian++)
                            printf("-");
                        printf("\n");
							
                        printf("|");
                        printf("%-8d",person[k].id);	
                        printf("|");
                        printf("%-12s",person[k].name);
                        printf("|");	
                        printf("%-6s",person[k].sex);
                        printf("|");
                        printf("%-14s",person[k].born);
                        printf("|");	
                        printf("%-15s",person[k].number);	
                        printf("|");
                        printf("%-22s",person[k].email);
                        printf("|");
                        printf("%-10s",person[k].max_study);
                        printf("|");
                        printf("%-20s",person[k].school);
                        printf("|");
                        printf("%-16s",person[k].major);
                        printf("|");
                        printf("%-10s",person[k].work_year);
                        printf("|");
                        printf("%-16s",person[k].think);
                        printf("|");
                        printf("%-20s",person[k].advantage);
                        printf("|");
                        printf("%-20s",person[k].company_name);
                        printf("|");
                        printf("%-18s",person[k].company_time);
                        printf("|");
                        printf("%-20s",person[k].company_work);
                        printf("|");
                        printf("%-16s",person[k].tip);
                        printf("|");
                        printf("\n");
                        
                        for(xian=1;xian<=261;xian++)
                            printf("-");
                        printf("\n");
						
						flag=1;				
						{
								int select2;
				
								printf("\t\t\t-------------------------------------------------\n");
								printf("\t\t\t-----------1 全部修改        2 部分修改-------------\n");
								printf("\t\t\t-------------------------------------------------\n");
								printf("\t\t\t请输入你的选择(1 or 2):");
								scanf("%d",&select2);
												
								//必须保证输入的给select值是1 或者 2
								while(select2<1 || select2>2)
								{
									printf("\t\t\t你输入错误，请重新输入你的选择(1 or 2):");
									scanf("%d",&select2);		
								}
									
								if(select2==1)//调用全部修改函数
									all_change(idx);
								if(select2==2)//调用部分修改函数
									part_change(idx);									 
						}
						break; 	
					}
				}
				
				if(flag==0)
					printf("\n\n\n\t\t\t不存在此药材！\n");
				
				change();//继续修改 
				break;

		case 2:break;	
	}
}