void input()
{
	system("clear");//系统函数,cls是clears 清屏 
	int i,j;
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t------------欢迎使用简历信息录入功能-------------\n");
	printf("\t\t\t-------------------------------------------------\n");
	printf("\n\n\n");
	
	for(i=0;i<=199;i++)
	{
		if(person[i].id==0)
		{
				int select;
				system("clear");
				printf("\t\t\t-------------------------------------------------\n");
				printf("\t\t\t----------1 确定输入        2 放弃输入-----------\n");
				printf("\t\t\t-------------------------------------------------\n");
				printf("\t\t\t请输入你的选择(1 or 2):");
				scanf("%d",&select);
				
				while(select<1 || select>2)
				{
					printf("\t\t\t你输入错误，请重新输入你的选择(1 or 2):");
					scanf("%d",&select);		
				}
				
				if(select==2)
					break; 
				
				printf("输入编号:");
		here:	scanf("%d",&person[i].id);
				getchar();
				for(j=0;j<=199;j++)
				{
					if(person[i].id==person[j].id && j!=i)
					{
						printf("你所输入的简历编号已经存在，请你重新输入简历编号:");
						goto here;  
					}
				}
				
                printf("输入姓名:");
                fgets(person[i].name,sizeof person[i].name,stdin);
				person[i].name[strcspn(person[i].name, "\n")] = '\0';
                printf("输入性别:");
                fgets(person[i].sex,sizeof person[i].sex,stdin);
                person[i].sex[strcspn(person[i].sex, "\n")] = '\0';
                printf("输入出生年月日(以xxxx.xx.xx作为模板):");
                fgets(person[i].born,sizeof person[i].born,stdin);
                person[i].born[strcspn(person[i].born, "\n")] = '\0';
                printf("输入联系电话:");
                fgets(person[i].number,sizeof person[i].number,stdin);
				person[i].number[strcspn(person[i].number, "\n")] = '\0';
                printf("输入个人电子邮箱:");
                fgets(person[i].email,sizeof person[i].email,stdin);
				person[i].email[strcspn(person[i].email, "\n")] = '\0';
                printf("输入最高学历:");
                fgets(person[i].max_study,sizeof person[i].max_study,stdin);
                person[i].max_study[strcspn(person[i].max_study,"\n")] = '\0';
                printf("输入毕业院校:");
                fgets(person[i].school,sizeof person[i].school,stdin);
                person[i].school[strcspn(person[i].school,"\n")] = '\0';
                printf("输入专业:");
                fgets(person[i].major,sizeof person[i].major,stdin);
                person[i].major[strcspn(person[i].major,"\n")] = '\0';
                printf("输入工作年限:");
                fgets(person[i].work_year,sizeof person[i].work_year,stdin);
                person[i].work_year[strcspn(person[i].work_year,"\n")] = '\0';
                printf("输入求职意向:");
                fgets(person[i].think,sizeof person[i].think,stdin);
                person[i].think[strcspn(person[i].think,"\n")] = '\0';
                printf("输入技能特长:");
                fgets(person[i].advantage,sizeof person[i].advantage,stdin);
                person[i].advantage[strcspn(person[i].advantage,"\n")] = '\0';
                printf("输入工作时期公司的名称:");
                fgets(person[i].company_name,sizeof person[i].company_name,stdin);
                person[i].company_name[strcspn(person[i].company_name,"\n")] = '\0';
                printf("输入工作时期公司的任职时间:");
                fgets(person[i].company_time,sizeof person[i].company_time,stdin);
                person[i].company_time[strcspn(person[i].company_time,"\n")] = '\0';
                printf("输入工作时期公司的岗位职责:");
            	fgets(person[i].company_work,sizeof person[i].company_work,stdin);
                person[i].company_work[strcspn(person[i].company_work,"\n")] = '\0';
                printf("输入备注:");
                fgets(person[i].tip,sizeof person[i].tip,stdin);
                person[i].tip[strcspn(person[i].tip,"\n")] = '\0';
        }		
	}
	printf("按回车继续...\n");
	getchar();
	getchar();	
} 