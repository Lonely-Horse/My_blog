void load()
{
	int select;
	system("clear");//系统函数,cls是clears 清屏 
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t------------欢迎使用学生信息读取功能-------------\n");
	printf("\t\t\t-------------------------------------------------\n");
	printf("\n\n\n");
	
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t----------1 确定读取        2 放弃读取-----------\n");
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t请输入你的选择(1 or 2):");
	scanf("%d",&select);
				
	//必须保证输入的给select值是1 或者 2
	while(select<1 || select>2)
	{
		printf("\t\t\t你输入错误，请重新输入你的选择(1 or 2):");
		scanf("%d",&select);		
	}
	
	if(select==1)
	{
		FILE *fp;
		int i;
		fp=fopen("简历txt","r");
		if(fp==NULL)
		{
			printf("\n\n\n\t\t\t文件打开失败\n");
			exit(0); 
		}
		fread(person,sizeof(struct person),1500,fp);
		printf("\n\n\n\t\t\t数据读取中");
		for(i=1;i<=2;i++) 
		{
			printf("。");
			sleep(1);
		}
		fclose(fp);
		printf("\n\n\n\t\t\t数据已经读取成功\n");
	}
	else
		printf("\n\n\n\t\t\t你选择了放弃读取，程序中无数据!\n");
	
	printf("按回车继续...\n");
	getchar();
	getchar();		
}




