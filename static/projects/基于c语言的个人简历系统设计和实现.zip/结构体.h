struct person
{
    int id;
    char name[20];
    char sex[15];
    char born[15];
    char number[15];
    char email[20];
    char max_study[20];
    char school[20];
    char major[20];
    char work_year[20];
    char think[20];
    char advantage[20];
    char company_name[20];
    char company_time[20];
    char company_work[20];
    char tip[30]
};

struct person person[200],shanchu;