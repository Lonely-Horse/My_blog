#include"stdio.h"
#include"string.h"
#include"math.h"
#include"stdlib.h"
#include"unistd.h"

#include"结构体.h"
#include"input.h"
#include"output.h"
#include"search.h"
#include"save.h"
#include"load.h"
#include"part_change.h"
#include"all_change.h"
#include"change.h"
#include"deleted.h"
#include"statistics.h"
#include"menu.h"
void main()
{
    menu();
} 