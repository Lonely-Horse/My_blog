void part_change(int i)
{
	struct person temp;
	int select,j,xian;

	system("clear");//系统函数,cls是clears 清屏 
	printf("\t\t\t--------------------------------------------------\n");
	printf("\t\t\t-------------欢迎使用简历信息部分修改功能--------------\n");
	printf("\t\t\t-----------          1 修改电话号码        -----------\n"); 
	printf("\t\t\t-----------          2 修改技能特长        -----------\n"); 
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t请输入你的选择(1 - 2):");
	scanf("%d",&select);
	while(select<1 || select>2)
	{
		printf("\t\t\t你输入错误，请重新输入你的选择(1 - 2):");
		scanf("%d",&select);
	}
	
	if(select==1) 
	{
		printf("输入新的电话号码:");
        fgets(temp.number,sizeof temp.number,stdin);
		temp.number[strcspn(temp.number, "\n")] = '\0';
	}
	if(select==2)
	{			
				//输入之后的回车键处理掉
		getchar(); 
		printf("输入新的技能特长:");
		fgets(temp.advantage,sizeof temp.advantage,stdin);
		temp.advantage[strcspn(temp.advantage, "\n")] = '\0';
    }
	int select2;
	
	system("clear");//系统函数,cls是clears 清屏 
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t----------1 确定修改        2 放弃修改-----------\n");
	printf("\t\t\t-------------------------------------------------\n");
	printf("\t\t\t请输入你的选择(1 or 2):");
	scanf("%d",&select2);
				
	//必须保证输入的给select值是1 或者 2
	while(select2<1 || select2>2)
	{
		printf("\t\t\t你输入错误，请重新输入你的选择(1 or 2):");
		scanf("%d",&select2);		
	}
	
	if(select2==1)//确定修改
	{
		if(select==1)
			strcpy(person[i].number,temp.number);
		if(select==2)
			strcpy(person[i].advantage,temp.advantage);
		printf("\n\n\n\t\t\t你选择修改，数据已经修改成功!\n");
        for(xian=1;xian<=261;xian++)
            printf("-");
        printf("\n");
        printf("|");
        printf("%-10s","编号"); 
        printf("|");
        printf("%-14s","姓名");
        printf("|");   
        printf("%-8s","性别");
        printf("|");
        printf("%-19s","出生年月日");
        printf("|");    
        printf("%-19s","联系电话"); 
        printf("|");
        printf("%-28s","个人电子邮箱");
        printf("|");
        printf("%-14s","最高学历");
        printf("|");
        printf("%-24s","毕业院校");
        printf("|");
        printf("%-18s","专业");
        printf("|");
        printf("%-14s","工作年限");
        printf("|");
        printf("%-20s","求职意向");
        printf("|");
        printf("%-24s","技能特长");
        printf("|");
        printf("%-25s","前公司名称");
        printf("|");
        printf("%-25s","前公司任职时间");
        printf("|");
        printf("%-27s","前公司岗位职责");
        printf("|");
        printf("%-18s","备注");
        printf("|");
        printf("\n");
        for(xian=1;xian<=261;xian++)
            printf("-");
        printf("\n");

        for(i=0;i<=199;i++)
        {
                        printf("|");
                        printf("%-8d",person[i].id);	
                        printf("|");
                        printf("%-12s",person[i].name);
                        printf("|");	
                        printf("%-6s",person[i].sex);
                        printf("|");
                        printf("%-14s",person[i].born);
                        printf("|");	
                        printf("%-15s",person[i].number);	
                        printf("|");
                        printf("%-22s",person[i].email);
                        printf("|");
                        printf("%-10s",person[i].max_study);
                        printf("|");
                        printf("%-20s",person[i].school);
                        printf("|");
                        printf("%-16s",person[i].major);
                        printf("|");
                        printf("%-10s",person[i].work_year);
                        printf("|");
                        printf("%-16s",person[i].think);
                        printf("|");
                        printf("%-20s",person[i].advantage);
                        printf("|");
                        printf("%-20s",person[i].company_name);
                        printf("|");
                        printf("%-18s",person[i].company_time);
                        printf("|");
                        printf("%-20s",person[i].company_work);
                        printf("|");
                        printf("%-16s",person[i].tip);
                        printf("|");
                        printf("\n");
                        
                        for(xian=1;xian<=261;xian++)
                            printf("-");
                        printf("\n");
            }				
        
            save();		 
	}
	if(select2==2)
	{
		printf("\n\n\n\t\t\t你选择了放弃修改，数据保持原样!\n");
	}	
	printf("按回车继续...\n");
	getchar();
	getchar();
} 