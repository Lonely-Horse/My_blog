#!/bin/bash
# 自动安装依赖并后台运行
pip install -r requirements.txt
nohup python3 exporter.py > agent.log 2>&1 &
echo "✅ Agent started in background. Check agent.log for details."
